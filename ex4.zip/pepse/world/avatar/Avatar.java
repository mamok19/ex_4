package pepse.world.avatar;

import danogl.GameObject;
import danogl.collisions.Collision;
import danogl.gui.ImageReader;
import danogl.gui.UserInputListener;
import danogl.util.Vector2;
import danogl.gui.rendering.AnimationRenderable;
import pepse.Constants;

import java.awt.event.KeyEvent;

import static pepse.Constants.*;

/**
 * Represents the Avatar character in the game. The avatar can move left, right, and jump,
 * while consuming energy. The avatar's energy can also be replenished by picking up fruits.
 * @author Eilam Soroka, Maayan Felig
 */
public class Avatar extends GameObject {

    private static final Vector2 AVATAR_SIZE = new Vector2(50, 50);
    private static final float OFFSET_GROUND_START = 20f;
    private static final float GRAVITY = 1000f;
    private static final float WALK_SPEED = 300f;
    private static final float JUMP_SPEED = 600f;
    private static final int LEFT_RIGHT_MOVEMENT_COST = 2;
    private static final int JUMP_COST = 20;
    private static final int DOUBLE_JUMP_COST = 50;
    private static final int ENERGY_RETURN_AMOUNT = 1;
    private static final int FRUIT_ENERGY_VALUE = 10;
    private static final String[] IDLE_IMAGES = new String[]
    {"assets/idle_0.png","assets/idle_1.png","assets/idle_2.png","assets/idle_3.png"};
    private static final String[] WALKING_IMAGES = new String[]
            {"assets/run_0.png","assets/run_1.png","assets/run_2.png","assets/run_3.png"};
    private static final String[] JUMPING_IMAGES = new String[]
            {"assets/jump_0.png","assets/jump_1.png","assets/jump_2.png","assets/jump_3.png"};
    private static final double TIME_BETWEEN_ANIMATION_FRAMES = 0.2f;


    private static enum State {
        IDLE,
        WALKING,
        JUMPING
    }

    private boolean onGround;
    private boolean doubleJumpUsed;
    private final UserInputListener inputListener;
    private final ImageReader imageReader;
    private State currentState;
    private AnimationRenderable idleAnimation;
    private AnimationRenderable walkAnimation;
    private AnimationRenderable jumpAnimation;

    private int energyMeter;
    private boolean spaceWasPressed = false;


    /**
     * Constructs an Avatar object with the specified starting position, input listener,
     * and image reader.
     *
     * @param topLeftCorner The top-left corner position of the avatar.
     * @param inputListener The input listener used to handle user inputs.
     * @param imageReader   The image reader used to read image files for the avatar's animations.
     */
    public Avatar(Vector2 topLeftCorner,
                  UserInputListener inputListener,
                  ImageReader imageReader){
        super(new Vector2(topLeftCorner.x(),
                topLeftCorner.y() - AVATAR_SIZE.y() - OFFSET_GROUND_START) , AVATAR_SIZE,
                imageReader.readImage("assets/idle_0.png", true));
//        this.topleftCorner = topLeftCorner;
        this.inputListener = inputListener;
        this.imageReader = imageReader;
        physics().preventIntersectionsFromDirection(Vector2.ZERO);
        transform().setAccelerationY(GRAVITY);
        this.currentState = State.IDLE;
        this.energyMeter = MAX_ENERGY;
        this.doubleJumpUsed = false;

        this.idleAnimation = new AnimationRenderable(IDLE_IMAGES
                , imageReader, true, TIME_BETWEEN_ANIMATION_FRAMES);
        this.walkAnimation = new AnimationRenderable(WALKING_IMAGES
                , imageReader, true, TIME_BETWEEN_ANIMATION_FRAMES);
        this.jumpAnimation = new AnimationRenderable(JUMPING_IMAGES
                , imageReader, true, TIME_BETWEEN_ANIMATION_FRAMES);

        renderer().setRenderable(idleAnimation);

        setTag(Constants.AVATAR_TAG);
    }

    /**
     * Updates the avatar state based on the delta time, including movement and energy consumption.
     *
     * @param deltaTime The time delta since the last update.
     */
    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);
        handleMovement();
        updateState();
    }

    private void handleMovement() {
        boolean did_I_moved = left_right_movement_handler();
        jump_movement_handler();
        if (onGround && !did_I_moved && energyMeter < MAX_ENERGY) {
            energyMeter = Math.min(MAX_ENERGY, energyMeter + ENERGY_RETURN_AMOUNT);
        }
    }

    private void updateState() {
        if (!onGround) {
            setState(State.JUMPING);
        }
        else if (transform().getVelocity().x() != 0) {
            setState(State.WALKING);
        }
        else {
            setState(State.IDLE);
        }
    }

    private void setState(State newState) {
        if (newState == currentState) {
            return;
        }

        currentState = newState;

        switch (currentState) {
            case IDLE:
                renderer().setRenderable(idleAnimation);
                break;
            case WALKING:
                renderer().setRenderable(walkAnimation);
                break;
            case JUMPING:
                renderer().setRenderable(jumpAnimation);
                break;
        }
    }

    private void jump_movement_handler() {
        boolean spacePressed = inputListener.isKeyPressed(KeyEvent.VK_SPACE);

        if (spacePressed && !spaceWasPressed) {

            if (onGround && energyMeter >= JUMP_COST) {
                energyMeter -= JUMP_COST;
                transform().setVelocityY(-JUMP_SPEED);
                onGround = false;
            }

            else if (!onGround && !doubleJumpUsed && transform().getVelocity().y() > 0 &&
                    energyMeter >= DOUBLE_JUMP_COST) {
                energyMeter -= DOUBLE_JUMP_COST;
                transform().setVelocityY(-JUMP_SPEED);
                doubleJumpUsed = true;
            }
        }

        spaceWasPressed = spacePressed;
    }

    private boolean left_right_movement_handler() {
        float velocityX = 0;

        boolean left = inputListener.isKeyPressed(KeyEvent.VK_LEFT);
        boolean right = inputListener.isKeyPressed(KeyEvent.VK_RIGHT);

        if (left == right) {
            transform().setVelocityX(0);
            return false;
        }
        if (left) {
            velocityX -= WALK_SPEED;
        }
        if (right) {
            velocityX += WALK_SPEED;
        }

        boolean wantsToMove = (velocityX != 0);

        if (wantsToMove && onGround) {
            if (energyMeter >= LEFT_RIGHT_MOVEMENT_COST) {
                energyMeter -= LEFT_RIGHT_MOVEMENT_COST;
            } else {
                velocityX = 0;
                wantsToMove = false;
            }
        }
        if (velocityX > 0) {
            renderer().setIsFlippedHorizontally(false);
        }
        else if (velocityX < 0) {
            renderer().setIsFlippedHorizontally(true);
        }
        transform().setVelocityX(velocityX);
        return wantsToMove;
    }


    /**
     *  * Handles collision events when the avatar collides with another game object.
     *
     * @param other     The other game object involved in the collision.
     * @param collision The collision information.
     */
    @Override
    public void onCollisionEnter(GameObject other, Collision collision) {
        super.onCollisionEnter(other, collision);
        if (collision.getNormal().y() < 0 &&
                other.getTag().equals(TOP_LAYER_GROUND_BLOCK_TAG)) {

            onGround = true;
            doubleJumpUsed = false;
            transform().setVelocityY(0);
        }

    }

    /**
     * Adds energy to the avatar's energy meter, up to the maximum limit.
     *
     * @param energyToAdd The amount of energy to add.
     */
    public void addEnergy(int energyToAdd) {
        this.energyMeter = Math.min(this.energyMeter + energyToAdd, MAX_ENERGY);
    }

    /**
     * Returns the current energy level of the avatar.
     *
     * @return The current energy level.
     */
    public int getEnergyMeter() {
        return energyMeter;
    }

}
